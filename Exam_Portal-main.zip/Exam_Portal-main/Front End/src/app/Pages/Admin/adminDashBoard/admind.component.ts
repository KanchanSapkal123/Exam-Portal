import { Component } from '@angular/core';

@Component({
  selector: 'app-admind',
  templateUrl: './admind.component.html',
  styleUrls: ['./admind.component.css']
})
export class AdmindComponent {

}
